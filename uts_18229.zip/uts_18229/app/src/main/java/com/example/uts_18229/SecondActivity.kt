package com.example.uts_18229
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)

        val textViewSummary = findViewById<TextView>(R.id.textView)

        val title = intent.getStringExtra("TITLE")
    }
}