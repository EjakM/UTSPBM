import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.textView)
        val textView2 = findViewById<TextView>(R.id.textView2)
        val textView3 = findViewById<TextView>(R.id.textView3)
        val radioButton = findViewById<RadioButton>(R.id.radioButton)
        val radioButton2 = findViewById<RadioButton>(R.id.radioButton2)
        val checkBox = findViewById<CheckBox>(R.id.checkBox)
        val checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        val checkBox3 = findViewById<CheckBox>(R.id.checkBox3)
        val checkBox4 = findViewById<CheckBox>(R.id.checkBox4)
        val checkBox5 = findViewById<CheckBox>(R.id.checkBox5)
        val checkBox6 = findViewById<CheckBox>(R.id.checkBox6)

        val buttonSubmit = findViewById<Button>(R.id.buttonSubmit)



        buttonSubmit.setOnClickListener {
            val title = textView.text.toString()
            val watchFor = when (radioButton.checkedRadioButtonId) {
                R.id.radioButton -> "Adult"
                R.id.radioButton2 -> "Kids"
                else -> ""
            }

            val genres = mutableListOf<String>()
            if (checkBox.isChecked) genres.add("Thriller")
            if (checkBox2.isChecked) genres.add("Horror")
            if (checkBox3.isChecked) genres.add("Action")
            if (checkBox4.isChecked) genres.add("Romance")
            if (checkBox5.isChecked) genres.add("Comedy")
            if (checkBox6.isChecked) genres.add("Fantasy")


            val intent = Intent(this, SecondActivity::class.java).apply {
                putExtra("TITLE", title)
                putExtra("WATCH_FOR", watchFor)
                putExtra("GENRES", genres.joinToString(", "))

            }
            startActivity(intent)
        }
    }
}